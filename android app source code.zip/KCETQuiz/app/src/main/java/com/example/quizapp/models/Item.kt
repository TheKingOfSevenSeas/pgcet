package com.example.quizapp.models

data class Item(val img: Int, val description: String, val extra: String)