package com.example.quizapp.models

data class Subject(
    val subject: String,
    val questions: List<Question>
)