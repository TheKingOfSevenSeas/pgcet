package com.example.quizapp.models

data class SubjectsWrapper(
    val subjects: List<Subject>
)